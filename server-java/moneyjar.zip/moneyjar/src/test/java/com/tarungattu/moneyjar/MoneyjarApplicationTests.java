package com.tarungattu.moneyjar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyjarApplicationTests {

	@Test
	void contextLoads() {
	}

}
