package com.tarungattu.moneyjar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoneyjarApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoneyjarApplication.class, args);
	}

}
